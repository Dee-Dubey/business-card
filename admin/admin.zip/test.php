<?php

foreach($_SERVER as $server => $value){
	echo $server.','.$value.'<br>';
}


?>