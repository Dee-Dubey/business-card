

<?php

require('connect.php');


		
		
	// activate or deactivate users card from digi card
if(isset($_POST['activate_user'])){
	$query=mysqli_query($connect,'SELECT * FROM digi_card WHERE id="'.$_POST['card_id'].'" AND d_card_status="Active"');
	
	if(mysqli_num_rows($query) > 0){
		$id_gal=mysqli_query($connect,"UPDATE digi_card SET d_card_status='Inactive' WHERE id=".$_POST['card_id']." ");
		if($id_gal){echo '<span class="alert danger">Inactive</div>';}
	}else {
		$id_gal=mysqli_query($connect,"UPDATE digi_card SET d_card_status='Active', d_payment_status='Success' WHERE id=".$_POST['card_id']." ");
		if($id_gal){echo '<span class="alert success">Active</div>';}
	}
}			
		
	// activate or deactivate users card from login
if(isset($_POST['fr_id'])){
	$query=mysqli_query($connect,'SELECT * FROM franchisee_login WHERE id="'.$_POST['fr_id'].'" AND f_user_active="YES"');
	
	if(mysqli_num_rows($query) > 0){
		$id_gal=mysqli_query($connect,"UPDATE franchisee_login SET f_user_active='NO' WHERE id=".$_POST['fr_id']." ");
		if($id_gal){echo '<span class="alert danger">NO</div>';}
	}else {
		$id_gal=mysqli_query($connect,"UPDATE franchisee_login SET f_user_active='YES' WHERE id=".$_POST['fr_id']." ");
		if($id_gal){echo '<span class="alert success">YES</div>';}
	}
}	

// image remove from page 

if(isset($_POST['id'])){
	$query=mysqli_query($connect,'SELECT * FROM digi_card2 WHERE id="'.$_POST['id'].'" ');
	$value=$_POST['d_pro_img'];
	if(mysqli_num_rows($query) > 0){
		$remove_img=mysqli_query($connect,"UPDATE digi_card2 SET d_pro_img$value='',d_pro_name$value='' WHERE id=".$_POST['id']." ");
		if($remove_img){echo '<div class="alert success">"'.$value.'" Image and discription is removed.</div>';}
	}else {
		echo '<div class="alert danger">Image Id is not available</div>';
	}
}
	
if(isset($_POST['id_gal'])){
	$query=mysqli_query($connect,'SELECT * FROM digi_card3 WHERE id="'.$_POST['id_gal'].'" ');
	$value=$_POST['d_gall_img'];
	if(mysqli_num_rows($query) > 0){
		$id_gal=mysqli_query($connect,"UPDATE digi_card3 SET d_gall_img$value='' WHERE id=".$_POST['id_gal']." ");
		if($id_gal){echo '<div class="alert success">"'.$value.'" Image is removed.</div>';}
	}else {
		echo '<div class="alert danger">Image Id is not available</div>';
	}
}


if(isset($_POST['pro_id'])){
	$query=mysqli_query($connect,'SELECT * FROM products WHERE id="'.$_POST['pro_id'].'" ');
	$value=$_POST['pro_num'];
	if(mysqli_num_rows($query) > 0){
		$id_gal=mysqli_query($connect,"UPDATE products SET pro_name$value='',pro_mrp$value='',pro_price$value='',pro_img$value='' WHERE id=".$_POST['pro_id']." ");
		if($id_gal){echo '<div class="alert success">"'.$value.'" product is removed.</div>';}
	}else {
		echo '<div class="alert danger">Product Deleted, refresh the page to see update.</div>';
	}
}

	
?>